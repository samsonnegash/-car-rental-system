<?php
$dalTablecarsbcolor = array();
$dalTablecarsbcolor["color"] = array("type"=>200,"varname"=>"color", "name" => "color");
$dalTablecarsbcolor["id"] = array("type"=>3,"varname"=>"id", "name" => "id");
$dalTablecarsbcolor["rgb"] = array("type"=>200,"varname"=>"rgb", "name" => "rgb");
	$dalTablecarsbcolor["id"]["key"]=true;

$dal_info["Cars_at_localhost__carsbcolor"] = &$dalTablecarsbcolor;
?>