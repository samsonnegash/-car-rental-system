<?php
$dalTablecarscars = array();
$dalTablecarscars["category"] = array("type"=>3,"varname"=>"category", "name" => "category");
$dalTablecarscars["color"] = array("type"=>200,"varname"=>"color", "name" => "color");
$dalTablecarscars["Date Listed"] = array("type"=>7,"varname"=>"Date_Listed", "name" => "Date Listed");
$dalTablecarscars["descr"] = array("type"=>201,"varname"=>"descr", "name" => "descr");
$dalTablecarscars["EPACity"] = array("type"=>200,"varname"=>"EPACity", "name" => "EPACity");
$dalTablecarscars["EPAHighway"] = array("type"=>200,"varname"=>"EPAHighway", "name" => "EPAHighway");
$dalTablecarscars["features"] = array("type"=>201,"varname"=>"features", "name" => "features");
$dalTablecarscars["Horsepower"] = array("type"=>3,"varname"=>"Horsepower", "name" => "Horsepower");
$dalTablecarscars["id"] = array("type"=>3,"varname"=>"id", "name" => "id");
$dalTablecarscars["Make"] = array("type"=>3,"varname"=>"Make", "name" => "Make");
$dalTablecarscars["Model"] = array("type"=>3,"varname"=>"Model", "name" => "Model");
$dalTablecarscars["Phone #"] = array("type"=>200,"varname"=>"Phone__", "name" => "Phone #");
$dalTablecarscars["Picture"] = array("type"=>200,"varname"=>"Picture", "name" => "Picture");
$dalTablecarscars["Price"] = array("type"=>3,"varname"=>"Price", "name" => "Price");
$dalTablecarscars["UserID"] = array("type"=>200,"varname"=>"UserID", "name" => "UserID");
$dalTablecarscars["YearOfMake"] = array("type"=>3,"varname"=>"YearOfMake", "name" => "YearOfMake");
$dalTablecarscars["zipcode"] = array("type"=>3,"varname"=>"zipcode", "name" => "zipcode");
	$dalTablecarscars["id"]["key"]=true;

$dal_info["Cars_at_localhost__carscars"] = &$dalTablecarscars;
?>