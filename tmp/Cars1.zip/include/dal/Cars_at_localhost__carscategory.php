<?php
$dalTablecarscategory = array();
$dalTablecarscategory["id"] = array("type"=>3,"varname"=>"id", "name" => "id");
$dalTablecarscategory["category"] = array("type"=>200,"varname"=>"category", "name" => "category");
	$dalTablecarscategory["id"]["key"]=true;

$dal_info["Cars_at_localhost__carscategory"] = &$dalTablecarscategory;
?>