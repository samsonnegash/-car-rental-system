<div align=center><br><br>
Use <b>admin/admin</b> to login. This header can be found in Header item on the Editor screen.
</div>